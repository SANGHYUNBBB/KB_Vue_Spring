<!-- <script setup>은 Vue 3에서 Composition API를 더 간단하게 쓸 수 있게 해주는 문법임 -->
<script setup>
// RouterView는 vue-router에서 제공하는 컴포넌트임
// 현재 URL 경로에 따라 맞는 컴포넌트를 화면에 보여줌
import { RouterView } from 'vue-router';
import DefaultLayout from './components/layouts/DefaultLayout.vue';

</script>
<!-- 화면에 보여줄 HTML 구조 정의하는 부분임 -->
<template>
    <DefaultLayout>
<!-- RouterView는 라우터 설정에 따라 해당 컴포넌트를 이 위치에 표시함 -->
        <RouterView />
    </DefaultLayout>
</template>
<!-- scoped는 이 CSS가 이 컴포넌트에만 적용되게 제한해 줌 -->
<!-- scoped가 없으면 다른 컴포넌트를 합했을 때 모두 영향을 미치게 됨. 전역 설정이 됨. -->
<style scoped>
/* 아직 스타일 없음 */
</style>